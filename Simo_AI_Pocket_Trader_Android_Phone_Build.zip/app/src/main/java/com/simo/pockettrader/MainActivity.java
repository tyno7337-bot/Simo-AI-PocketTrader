package com.simo.pockettrader;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends Activity {
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setPadding(dp(12),dp(12),dp(12),dp(12)); return t;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1);
        root.setGravity(Gravity.CENTER); root.setPadding(dp(22),dp(22),dp(22),dp(22));
        root.setBackgroundColor(Color.rgb(16,24,39));
        root.addView(text("Simo AI Pocket Trader", 25));
        root.addView(text("مساعد إشارات تداول — مدة الصفقة: دقيقة واحدة", 16));
        TextView status = text("WAIT\nلا توجد بيانات أسعار مباشرة حالياً", 20);
        status.setBackgroundColor(Color.rgb(31,45,64));
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(150)));
        Button refresh = new Button(this); refresh.setText("تحديث الحالة");
        refresh.setOnClickListener(v -> status.setText("WAIT\nاربط مصدر بيانات أسعار موثوقاً قبل استخدام الإشارات"));
        root.addView(refresh);
        root.addView(text("تنبيه: هذا إصدار تجريبي لا يتصل بـ Pocket Option ولا ينفذ صفقات. لا تستخدمه لاتخاذ قرار مالي دون تحقق مستقل.", 13));
        setContentView(root);
    }
}
