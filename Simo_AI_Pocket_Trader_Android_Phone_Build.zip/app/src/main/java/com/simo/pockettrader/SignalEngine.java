package com.simo.pockettrader;

public class SignalEngine {
    public static String evaluate(double[] closes) {
        if (closes == null || closes.length < 200) return "انتظار: نحتاج 200 شمعة على الأقل";
        double ema50 = ema(closes, 50), ema200 = ema(closes, 200);
        double rsi = rsi(closes, 14);
        double last = closes[closes.length - 1];
        if (last > ema50 && ema50 > ema200 && rsi >= 50 && rsi <= 68) return "CALL — إشارة شراء محتملة";
        if (last < ema50 && ema50 < ema200 && rsi <= 50 && rsi >= 32) return "PUT — إشارة بيع محتملة";
        return "WAIT — لا توجد إشارة واضحة";
    }
    private static double ema(double[] a, int p) {
        double k = 2.0 / (p + 1), e = a[a.length-p];
        for (int i = a.length-p+1; i < a.length; i++) e = a[i]*k + e*(1-k);
        return e;
    }
    private static double rsi(double[] a, int p) {
        double gain=0, loss=0;
        for (int i=a.length-p; i<a.length; i++) {
            double d=a[i]-a[i-1];
            if (d>0) gain+=d; else loss-=d;
        }
        if (loss==0) return 100;
        double rs=(gain/p)/(loss/p);
        return 100-(100/(1+rs));
    }
}
